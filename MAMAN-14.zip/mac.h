#ifndef MAC
#define MAC
#include <stdio.h>
#include "globals.h"

extern boolean mac_move(FILE *, FILE *);

#endif