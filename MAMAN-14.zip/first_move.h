#ifndef FMOVE
#define FMOVE
#include <stdio.h>
#include "globals.h"
#include "thing.h"
#include "table.h"

extern boolean first_move(FILE *,char *,
    thing **,int *,int *, int *,table *);

#endif
